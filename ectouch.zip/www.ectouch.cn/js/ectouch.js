//banner
$(".pt-title").animate({top:"150px",opacity:"1"},1000,"swing")
$(".pt-phone").delay(100).animate({top:"410px",opacity:"1"},1000,"swing");



$(function($) {
	//微信二维码
	$(".index-weixin-box").mouseover(function() {
		$(".footer-ewm-img").addClass("active");
	});
	$(".index-weixin-box").mouseout(function() {
		$(".footer-ewm-img").removeClass("active");
	});
	//qq
	$(".index-qq-box").mouseover(function() {
		$(this).find(".an-show").addClass("active");
	});
	$(".index-qq-box").mouseout(function() {
		$(this).find(".an-show").removeClass("active");
	});
	//weibo
	$(".index-weibo-box").mouseover(function() {
		$(this).find(".an-show").addClass("active");
	});
	$(".index-weibo-box").mouseout(function() {
		$(this).find(".an-show").removeClass("active");
	});
});
$(function(){
    // 右侧悬浮
     var tophtml="<div id=\"izl_rmenu\" class=\"izl-rmenu\"><a href=\"http://q.url.cn/s/IygMzVm\" target=\"_blank\"  class=\"btn btn-qq\" id=\"webqq\"></a><div class=\"btn btn-wx\"><img class=\"pic\" src=\"images/weixin.jpg\" onclick=\"window.location.href=\'index.html\'\"/></div><div class=\"btn btn-phone\"><div class=\"phone\">Tel: 4001-021-758</div></div><div class=\"btn btn-top\"></div></div>";
	$("#top").html(tophtml);
	$("#izl_rmenu").each(function(){
		$(this).find(".btn-wx").mouseenter(function(){
			$(this).find(".pic").fadeIn("fast");
		});
		$(this).find(".btn-wx").mouseleave(function(){
			$(this).find(".pic").fadeOut("fast");
		});
		$(this).find(".btn-phone").mouseenter(function(){
			$(this).find(".phone").fadeIn("fast");
		});
		$(this).find(".btn-phone").mouseleave(function(){
			$(this).find(".phone").fadeOut("fast");
		});
		$(this).find(".btn-top").click(function(){
			$("html, body").animate({
				"scroll-top":0
			},"fast");
		});
	});
	var lastRmenuStatus=false;
	$(window).scroll(function(){//bug
		var _top=$(window).scrollTop();
		if(_top>200){
			$("#izl_rmenu").data("expanded",true);
		}else{
			$("#izl_rmenu").data("expanded",false);
		}
		if($("#izl_rmenu").data("expanded")!=lastRmenuStatus){
			lastRmenuStatus=$("#izl_rmenu").data("expanded");
			if(lastRmenuStatus){
				$("#izl_rmenu .btn-top").slideDown();
			}else{
				$("#izl_rmenu .btn-top").slideUp();
			}
		}
	});




	$(window).scroll(function(){
		    // header
			if ($(window).scrollTop() > 100) {
				$(".index-header").addClass("active");
			} else {
				$(".index-header").removeClass("active");
			};
		 
	})
})



